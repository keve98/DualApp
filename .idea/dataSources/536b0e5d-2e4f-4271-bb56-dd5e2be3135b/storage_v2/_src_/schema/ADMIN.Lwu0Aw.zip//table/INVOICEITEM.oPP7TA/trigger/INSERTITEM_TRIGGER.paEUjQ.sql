create trigger INSERTITEM_TRIGGER
    after insert
    on INVOICEITEM
begin
    update INVOICEITEM
    set TOTALITEMPRICE = QUANTITY*UNITPRICE;

end;
/

