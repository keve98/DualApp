create trigger INVOICE_TOTAL_TRIGGER
    after insert
    on INVOICEITEM
declare 
    total number;

begin

    select sum(totalitemprice) into total
    from INVOICEITEM, INVOICE
    where invoice.id = invoiceitem.id;

    update invoice
    set invoicetotal = total;
end;
/

