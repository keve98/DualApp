create trigger INVOICE_TOTAL_TRIGGER
    after insert
    on ORDERS
declare
    total number;

begin

    select sum(unitprice)into total
    from INVOICEITEM, INVOICE, ORDERS
    where INVOICE.ID = ORDERS.INVOICEID and INVOICEITEM.ID = ORDERS.ITEMID;

    update INVOICE
    set INVOICETOTAL = total;
end;
/

